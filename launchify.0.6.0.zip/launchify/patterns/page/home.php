<?php
/**
 * Title: Page Home
 * Slug: home
 * Categories: page
 * Block Types: core/post-content
 */
?>
<!-- wp:pattern {"slug":"hero-default","preview":false} /-->
<!-- wp:pattern {"slug":"testimonial-brands"} /-->
<!-- wp:pattern {"slug":"feature-solutions"} /-->
<!-- wp:pattern {"slug":"feature-stats"} /-->
<!-- wp:pattern {"slug":"feature-sections"} /-->
<!-- wp:pattern {"slug":"feature-icons"} /-->
<!-- wp:pattern {"slug":"pricing-three-column"} /-->
<!-- wp:pattern {"slug":"testimonial-scroll"} /-->
<!-- wp:pattern {"slug":"faq-boxed"} /-->
<!-- wp:pattern {"slug":"cta-box"} /-->
<!-- wp:pattern {"slug":"blog-grid-boxed"} /-->
<!-- wp:pattern {"slug":"cta-full-width"} /-->
<!-- wp:pattern {"slug":"feature-marquee"} /-->